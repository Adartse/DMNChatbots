// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion} = require('dialogflow-fulfillment');

var list_rules =[
  {existingcustomer:"True", riskscore:"<=120", creditscore:"<590", decision:"HIGH"},
  {existingcustomer:"True", riskscore:"<=120", creditscore:"[590..610]", decision:"MEDIUM"},
  {existingcustomer:"True", riskscore:"<=120", creditscore:">610", decision:"LOW"},
  {existingcustomer:"True", riskscore:">120", creditscore:"<600", decision:"HIGH"},
  {existingcustomer:"True", riskscore:">120", creditscore:"[600..625]", decision:"MEDIUM"},
  {existingcustomer:"True", riskscore:">120", creditscore:">625", decision:"LOW"},
  {existingcustomer:"False", riskscore:"<=100", creditscore:"<580", decision:"HIGH"},
  {existingcustomer:"False", riskscore:"<=100", creditscore:"[580..600]", decision:"MEDIUM"},
  {existingcustomer:"False", riskscore:"<=100", creditscore:">600", decision:"LOW"},
  {existingcustomer:"False", riskscore:">100", creditscore:"<590", decision:"HIGH"},
  {existingcustomer:"False", riskscore:">100", creditscore:"[590..615]", decision:"MEDIUM"},
  {existingcustomer:"False", riskscore:">100", creditscore:">615", decision:"LOW"}
];

//<-- My variables...
var maindecision = "";
var existingcustomer = "";
var riskscore = "";
var creditscore = "";
var decision_made = "";
// ..My variables-->
 
process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements
 
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));

  function dmn_maindecision_intent(agent) {
    maindecision = agent.parameters.ent_maindecision;
    existingcustomer = agent.parameters.ent_existingcustomer;
    riskscore = agent.parameters.p_riskscore;
    creditscore = agent.parameters.p_creditscore;
    
    //agent.add(`RESPONSE:: maindecision[${maindecision}] -- existingcustomer[${existingcustomer}] -- riskscore[${riskscore}] -- creditscore[${creditscore}]`);
  
    //Checking parameters
    if(existingcustomer == ""){ //(1) /*--------------------------------------------------------------*/      
      //(2)
      if(hasAllWildCard('existingcustomer')){ //(3) - Don't ask for "Attributo 1"
      //Do not ask for attribute 1. Ask for attribute 2 o 3
        existingcustomer = "-";
        
        /******START_BLOCK_B*******/
        if(riskscore == ""){	//(6) 
			if(hasAnyWildCard('riskscore')){ //(7) - Does it have any wild cards?
			  //(8) - Verify if the previous value affects the same rules with wildcards
			  var omit_att2_b = reviewBeforeAskForAtt2('existingcustomer', existingcustomer, 'riskscore');
			  if(omit_att2_b){ //(10) - TRUE-Omit_Att2
			  //Do not ask for Attribute 2. Ask for attribute 3
				riskscore = "-";
				if(creditscore == ""){ //(13)	
				  if(hasAnyWildCard('creditscore')){ //(14) - Does it have any wild cards?
					//(16) - Verify if the previous value affects the same rules with wildcards
					var omit_att3_b = reviewBeforeAskForAtt3('existingcustomer', existingcustomer, 'riskscore', riskscore, 'creditscore');
					if(omit_att3_b){ //(17) - TRUE-Omit_Att3
					  creditscore = "-";
					  decision_made = makedecision(); //(21) - Derived from 20
					  showDecision(agent, decision_made);
					}
					else{
					  askForAtt3(agent); //(18) - Ask for Attribute 3.
					}
				  }else{ //(15) - Don't ask for Attribute 2. Ask for Attribute 3.
					askForAtt3(agent);
				  }
				}else{//(19) - I have all attributes
				  decision_made = makedecision(); //(20) - Make decision
				  showDecision(agent, decision_made);
				}			
			  }else{ //(11) - FALSE-Ask_for_Att2
				askForAtt2(agent);
			  }
			}else{ //(9) - Ask for Attribute 2.
			  askForAtt2(agent);
			}			
		  }else{ //(12) 
			if(creditscore == ""){ //(13)	
			  if(hasAnyWildCard('creditscore')){ //(14) - Does it have any wild cards?
				//(16) - Verify if the previous value affects the same rules with wildcards
				var omit_att3_c = reviewBeforeAskForAtt3('existingcustomer', existingcustomer, 'riskscore', riskscore, 'creditscore');
				if(omit_att3_c){ //(17) - TRUE-Omit_Att3
				  creditscore = "-";
				  decision_made = makedecision(); //(21) - Derived from 20
				  showDecision(agent, decision_made);
				}
				else{
				  askForAtt3(agent); //(18) - Ask for Attribute 3.
				}
			  }else{ //(15) - Don't ask for Attribute 2. Ask for Attribute 3.
				askForAtt3(agent);
			  }
			}else{//(19) - I have all attributes
			  decision_made = makedecision(); //(20) - Make decision
			  showDecision(agent, decision_made);
			}
		}
		/******END_BLOCK_B*******/
        
      }else{	//(4) - Tengo que pedir "Atributo 1"
      	askForAtt1(agent);
      }
    }else{// (5) - I have Attribute_1. Ask for Attribute_2: RiskScore
      if(riskscore == ""){	//(6) /*------------------------------------------------------------------*/
        if(hasAnyWildCard('riskscore')){ //(7) - Does it have any wild cards?
          //(8) - Verify if the previous value affects the same rules with wildcards
          var omit_att2 = reviewBeforeAskForAtt2('existingcustomer', existingcustomer, 'riskscore');
          if(omit_att2){ //(10) - TRUE-Omit_Att2
          //Do not ask for Attribute 2. Ask for attribute 3
            riskscore = "-";
            
            /******START_BLOCK_A*******/
            if(creditscore == ""){ //(13)	
			  if(hasAnyWildCard('creditscore')){ //(14) - Does it have any wild cards?
				//(16) - Verify if the previous value affects the same rules with wildcards
				var omit_att3_a = reviewBeforeAskForAtt3('existingcustomer', existingcustomer, 'riskscore', riskscore, 'creditscore');
				if(omit_att3_a){ //(17) - TRUE-Omit_Att3
				  creditscore = "-";
				  decision_made = makedecision(); //(21) - Derived from 20
				  showDecision(agent, decision_made);
				}
				else{
				  askForAtt3(agent); //(18) - Ask for Attribute 3.
				}
			  }else{ //(15) - Don't ask for Attribute 2. Ask for Attribute 3.
				askForAtt3(agent);
			  }
			}else{//(19) - I have all attributes
			  decision_made = makedecision(); //(20) - Make decision
			  showDecision(agent, decision_made);
			}
            /******END_BLOCK_A*******/
            
          }else{ //(11) - FALSE-Ask_for_Att2
            askForAtt2(agent);
          }
        }else{ //(9) - Ask for Attribute 2.
          askForAtt2(agent);
        }
        
      }else{ //(12) /*--------------------------------------------------------------------------------*/
        if(creditscore == ""){ //(13)	
          if(hasAnyWildCard('creditscore')){ //(14) - Does it have any wild cards?
            //(16) - Verify if the previous value affects the same rules with wildcards
            var omit_att3 = reviewBeforeAskForAtt3('existingcustomer', existingcustomer, 'riskscore', riskscore, 'creditscore');
            if(omit_att3){ //(17) - TRUE-Omit_Att3
              creditscore = "-";
              decision_made = makedecision(); //(21) - Derived from 20
          	  showDecision(agent, decision_made);
            }
            else{
              askForAtt3(agent); //(18) - Ask for Attribute 3.
            }
          }else{ //(15) - Don't ask for Attribute 2. Ask for Attribute 3.
            askForAtt3(agent);
          }
        }else{//(19) - I have all attributes
          decision_made = makedecision(); //(20) - Make decision
          showDecision(agent, decision_made);
        }
      }
    }
  
  
  }
  
  function dmn_existingcustomer_intent(agent) {
    existingcustomer = agent.parameters.ent_existingcustomer; //It is a Required paramenter
    if(riskscore == ""){riskscore = agent.parameters.p_riskscore;}
    if(creditscore == ""){creditscore = agent.parameters.p_creditscore;}
    
    /******START_BLOCK_B*******/
        if(riskscore == ""){	//(6) 
			if(hasAnyWildCard('riskscore')){ //(7) - Does it have any wild cards?
			  //(8) - Verify if the previous value affects the same rules with wildcards
			  var omit_att2_b = reviewBeforeAskForAtt2('existingcustomer', existingcustomer, 'riskscore');
			  if(omit_att2_b){ //(10) - TRUE-Omit_Att2
			  //Do not ask for Attribute 2. Ask for attribute 3
				riskscore = "-";
				if(creditscore == ""){ //(13)	
				  if(hasAnyWildCard('creditscore')){ //(14) - Does it have any wild cards?
					//(16) - Verify if the previous value affects the same rules with wildcards
					var omit_att3_b = reviewBeforeAskForAtt3('existingcustomer', existingcustomer, 'riskscore', riskscore, 'creditscore');
					if(omit_att3_b){ //(17) - TRUE-Omit_Att3
					  creditscore = "-";
					  decision_made = makedecision(); //(21) - Derived from 20
					  showDecision(agent, decision_made);
					}
					else{
					  askForAtt3(agent); //(18) - Ask for Attribute 3.
					}
				  }else{ //(15) - Don't ask for Attribute 2. Ask for Attribute 3.
					askForAtt3(agent);
				  }
				}else{//(19) - I have all attributes
				  decision_made = makedecision(); //(20) - Make decision
				  showDecision(agent, decision_made);
				}			
			  }else{ //(11) - FALSE-Ask_for_Att2
				askForAtt2(agent);
			  }
			}else{ //(9) - Ask for Attribute 2.
			  askForAtt2(agent);
			}			
		  }else{ //(12) 
			if(creditscore == ""){ //(13)	
			  if(hasAnyWildCard('creditscore')){ //(14) - Does it have any wild cards?
				//(16) - Verify if the previous value affects the same rules with wildcards
				var omit_att3_c = reviewBeforeAskForAtt3('existingcustomer', existingcustomer, 'riskscore', riskscore, 'creditscore');
				if(omit_att3_c){ //(17) - TRUE-Omit_Att3
				  creditscore = "-";
				  decision_made = makedecision(); //(21) - Derived from 20
				  showDecision(agent, decision_made);
				}
				else{
				  askForAtt3(agent); //(18) - Ask for Attribute 3.
				}
			  }else{ //(15) - Don't ask for Attribute 2. Ask for Attribute 3.
				askForAtt3(agent);
			  }
			}else{//(19) - I have all attributes
			  decision_made = makedecision(); //(20) - Make decision
			  showDecision(agent, decision_made);
			}
		}    
  }
  
  function dmn_riskscore_intent(agent) {    
    riskscore = agent.parameters.p_riskscore;  //It is a Required paramenter
    //if(existingcustomer == ""){existingcustomer = agent.parameters.ent_existingcustomer;}
    if(creditscore == ""){creditscore = agent.parameters.p_creditscore;}
    
    /******START_BLOCK_A*******/
    if(creditscore == ""){ //(13)	
      if(hasAnyWildCard('creditscore')){ //(14) - Does it have any wild cards?
        //(16) - Verify if the previous value affects the same rules with wildcards
        var omit_att3_a = reviewBeforeAskForAtt3('existingcustomer', existingcustomer, 'riskscore', riskscore, 'creditscore');
        if(omit_att3_a){ //(17) - TRUE-Omit_Att3
          creditscore = "-";
          decision_made = makedecision(); //(21) - Derived from 20
          showDecision(agent, decision_made);
        }
        else{
          askForAtt3(agent); //(18) - Ask for Attribute 3.
        }
      }else{ //(15) - Don't ask for Attribute 2. Ask for Attribute 3.
        askForAtt3(agent);
      }
    }else{//(19) - I have all attributes
      decision_made = makedecision(); //(20) - Make decision
      showDecision(agent, decision_made);
    }
    /******END_BLOCK_A*******/
  }
  
  function dmn_creditscore_intent(agent) {
    creditscore = agent.parameters.p_creditscore;  //It is a Required paramenter
    if(riskscore == ""){riskscore = agent.parameters.p_riskscore;}
    //if(existingcustomer == ""){existingcustomer = agent.parameters.ent_existingcustomer;}
    
    var decision_made_cs = makedecision(); //(20) - Make decision
    showDecision(agent, decision_made_cs);
    
  }
  /******************************************/
  function askForAtt1(agent){
    agent.add(`Do you have an EXISTING CUSTOMER?`);
    //agent.add(`Do you have an EXISTING CUSTOMER? -- riskscore[${riskscore}] -- creditscore[${creditscore}]`);
    agent.setContext({
      name: 'awaiting_existingcustomer',
      lifespan: 4,
      parameters:{
        ent_existingcustomer: existingcustomer,
        p_riskscore: riskscore,
        p_creditscore: creditscore
      }
    });
  }
  
  //ent_existingcustomer: existingcustomer,
  function askForAtt2(agent){
    agent.add(`What is the RISK SCORE value?`);
    //agent.add(`What is the RISK SCORE value? -- riskscore[${riskscore}] -- creditscore[${creditscore}]`);
    agent.setContext({
      name: 'awaiting_riskscore',
      lifespan: 4,
      parameters:{
        p_riskscore: riskscore,
        p_creditscore: creditscore
      }
    });
  }
  
  //ent_existingcustomer: existingcustomer,
  function askForAtt3(agent){
    agent.add(`What is the CREDIT SCORE value?`);
    //agent.add(`What is the CREDIT SCORE value? -- riskscore[${riskscore}] -- creditscore[${creditscore}]`);
    agent.setContext({
      name: 'awaiting_creditscore',
      lifespan: 4,
      parameters:{        
        p_riskscore: riskscore,
        p_creditscore: creditscore
      }
    });
  }
  
  function showDecision(agent, decision){
    agent.add(`Based on the data provided, the Risk Category is [${decision}] -- Values used :: Existing customer[${existingcustomer}]; Risk Score[${riskscore}];Credit Score[${creditscore}]`);
    //agent.add(`Values used :: Existing customer[${existingcustomer}]; Risk Score[${riskscore}];Credit Score[${creditscore}]`);
  }
  
  function hasAllWildCard(att_name){ //True si todos los valores son "-", sino "False"
	var total_rules = list_rules.length;
	var partial_rules = 0;
    
	for (var rule of list_rules){
		if(rule[att_name] == "-")
			partial_rules += 1;
	}
	if(total_rules == partial_rules){return true;}
	else{return false;}
  }
    
  function hasAnyWildCard(att_name){ //True or False dependiendo de si tiene algún "-" el atributo dado.
    for (var rule of list_rules){
      if(rule[att_name] == "-")
        return true;
    }
    return false;
  }
  
  function reviewBeforeAskForAtt2(att1_name, att1_value, att2_name){
	//TRUE-Omit_Att2; FALSE-Ask_for_Att2
    var numTotGuiones2 = 0;
    var numConGuiones2 = 0;

    for (var rule of list_rules){	

      if(rule[att1_name] == att1_value || rule[att1_name] == "-"){
        numTotGuiones2 += 1;
      }
      if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (rule[att2_name] == "-")){
        numConGuiones2 += 1;        
      }
    }

    if((numTotGuiones2 == numConGuiones2) && (numConGuiones2 != 0)){
      return true;		//I only hace WildCards, so DONT ASK for ATTRIBUTE 2
    }else{
        return false;	//They are different, ASK for ATTRIBUTE 2
    }

  }
  
  function reviewBeforeAskForAtt3(att1_name, att1_value, att2_name, att2_value, att3_name){
	
	var att2_part1 = ""; //This is empty or a comparison or a range
	var att2_part2 = ""; //This is a number
	var att2_part2_A = ""; //This is the first number in the range
	var att2_part2_B = ""; //This is the second number in the range
	var complete_att ="";
	
	var numTotGuiones = 0;
	var numConGuiones = 0;
		
	for (var rule of list_rules){
		
		complete_att = rule[att2_name];
		
		if(complete_att == "-"){
			att2_part1 = "ALL2";
			att2_part2 = "-";
		}else{
			if(complete_att.startsWith('[') || complete_att.startsWith(']')){	//Es un rango - tengo dos valores
				att2_part1 = complete_att.substring(0, 1) + complete_att.slice(-1); //[], ][, [[, ]]
				att2_part2_A = complete_att.substring(1, complete_att.indexOf("."));
				att2_part2_B = complete_att.substring(complete_att.lastIndexOf(".")+1,complete_att.length - 1);							
			}else{
				if(complete_att.startsWith('>=') || complete_att.startsWith('<=')){
					att2_part1 = complete_att.substring(0,2);
					att2_part2 = complete_att.substring(2);	
				}else{
					if(complete_att.startsWith('>') || complete_att.startsWith('<')){
						att2_part1 = complete_att.substring(0,1);
						att2_part2 = complete_att.substring(1);						
					}else{
						att2_part1 = "EMPTY";
						att2_part2 = complete_att;
					}
				}
			}
		}
		
		switch (att2_part1) { 
			case "ALL2":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-")){
					numTotGuiones += 1;					
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;
			
			case "EMPTY":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value == att2_part2)){
					numTotGuiones += 1;					
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value == att2_part2) && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;
				
			case ">":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value > att2_part2)){
					numTotGuiones += 1;					
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value > att2_part2) && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;
				
			case ">=":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value >= att2_part2)){
					numTotGuiones += 1;					
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value >= att2_part2) && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;
				
			case "<":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value < att2_part2)){
					numTotGuiones += 1;					
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value < att2_part2) && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;
				
			case "<=":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value <= att2_part2)){
					numTotGuiones += 1;					
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value <= att2_part2) && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;
				
			case "[]":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value >= att2_part2_A && att2_value <= att2_part2_B)){
					numTotGuiones += 1;					
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value >= att2_part2_A && att2_value <= att2_part2_B) && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;
			
			case "][":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value > att2_part2_A && att2_value < att2_part2_B)){
					numTotGuiones += 1;					
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value > att2_part2_A && att2_value < att2_part2_B) && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;
			
			case "]]":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value > att2_part2_A && att2_value <= att2_part2_B)){
					numTotGuiones += 1;
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value > att2_part2_A && att2_value <= att2_part2_B) && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;
				
			case "[[":
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value >= att2_part2_A && att2_value < att2_part2_B)){
					numTotGuiones += 1;
				}
				if((rule[att1_name] == att1_value || rule[att1_name] == "-") && (att2_value >= att2_part2_A && att2_value < att2_part2_B) && (rule[att3_name] == "-")){
					numConGuiones += 1;					
				}
				break;		
		}		
	}
	if((numTotGuiones == numConGuiones) && (numConGuiones != 0)){
		return true;						//I only have WildCard, DONT ask for ATTRIBUTE 3
	}else{
		return false;						//They are different, so ask for the ATTRIBUTE 3
	}
  }
  
  //ORIGINAL
  function makedecision(){
  	var decision = "";
    var num_riskscore = Number(riskscore);
    var num_creditscore = Number(creditscore);
        
    //Creating decision rules - example Page 106
    //RULE-1
    if((existingcustomer == "True") && (num_riskscore <= 120) && (num_creditscore < 590)){
    	decision = "HIGH";
    }
    //RULE-2
    if((existingcustomer == "True") && (num_riskscore <= 120) && (num_creditscore >= 590 && num_creditscore <= 610)){
    	decision = "MEDIUM";
    }
    //RULE-3
    if((existingcustomer == "True") && (num_riskscore <= 120) && (num_creditscore > 610)){
    	decision = "LOW";
    }
    //RULE-4
    if((existingcustomer == "True") && (num_riskscore > 120) && (num_creditscore < 600)){
    	decision = "HIGH";
    }
    //RULE-5
    if((existingcustomer == "True") && (num_riskscore > 120) && (num_creditscore >= 600 && num_creditscore <= 625)){
    	decision = "MEDIUM";
    }
    //RULE-6
    if((existingcustomer == "True") && (num_riskscore > 120) && (num_creditscore > 625)){
    	decision = "LOW";
    }
    //RULE-7
    if((existingcustomer == "False") && (num_riskscore <= 100) && (num_creditscore < 580)){
    	decision = "HIGH";
    }
    //RULE-8
    if((existingcustomer == "False") && (num_riskscore <= 100) && (num_creditscore >= 580 && num_creditscore <= 600)){
    	decision = "MEDIUM";
    }
    //RULE-9
    if((existingcustomer == "False") && (num_riskscore <= 100) && (num_creditscore > 600)){
    	decision = "LOW";
    }
    //RULE-10
    if((existingcustomer == "False") && (num_riskscore > 100) && (num_creditscore < 590)){
    	decision = "HIGH";
    }
    //RULE-11
    if((existingcustomer == "False") && (num_riskscore > 100) && (num_creditscore >= 590 && num_creditscore <= 615)){
    	decision = "MEDIUM";
    }
    //RULE-12
    if((existingcustomer == "False") && (num_riskscore > 100) && (num_creditscore > 615)){
    	decision = "LOW";
    } 
    
    //decision = `DECISION[${decision}] :: existingcustomer[${existingcustomer}]; riskscore[${riskscore}]; creditscore[${creditscore}]`;
  	return decision;
  }
  
  // Run the proper function handler based on the matched Dialogflow intent name
  let intentMap = new Map(); 
  intentMap.set('riskcategory_intent', dmn_maindecision_intent);
  intentMap.set('existingcustomer_intent', dmn_existingcustomer_intent);
  intentMap.set('riskscore_intent', dmn_riskscore_intent);
  intentMap.set('creditscore_intent', dmn_creditscore_intent);
  
  agent.handleRequest(intentMap);
});
